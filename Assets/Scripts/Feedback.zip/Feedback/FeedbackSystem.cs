using UnityEngine;
using UnityEngine.Events;
using TMPro;
using ASL_LearnVR.Data;
using ASL_LearnVR.Gestures;

namespace ASL_LearnVR.Feedback
{
    /// <summary>
    /// Sistema principal de feedback pedagógico.
    /// Orquesta visual, UI y audio para proporcionar feedback explicable al usuario.
    ///
    /// Responsabilidades:
    /// - Coordinar HandPoseAnalyzer, FeedbackUI, FeedbackAudio y FingerIndicatorVisualizer
    /// - Aplicar debounce (200ms) para evitar parpadeos
    /// - Escuchar eventos de GestureRecognizer y DynamicGestureRecognizer
    /// - Activar/desactivar feedback según el modo de práctica
    /// </summary>
    public class FeedbackSystem : MonoBehaviour
    {
        [Header("Components")]
        [Tooltip("Analizador de pose de mano")]
        [SerializeField] private HandPoseAnalyzer handPoseAnalyzer;

        [Tooltip("UI de feedback textual (opcional si usas Direct Text)")]
        [SerializeField] private FeedbackUI feedbackUI;

        [Tooltip("Audio de feedback")]
        [SerializeField] private FeedbackAudio feedbackAudio;

        [Tooltip("Visualizador de indicadores por dedo")]
        [SerializeField] private FingerIndicatorVisualizer fingerIndicatorVisualizer;

        [Header("Direct Text Output (Alternativa a FeedbackUI)")]
        [Tooltip("Si se asigna, el feedback se escribe directamente aquí (ej: feedbackText de LearningController)")]
        [SerializeField] private TextMeshProUGUI directFeedbackText;

        [Tooltip("Usar texto directo en lugar de FeedbackUI")]
        [SerializeField] private bool useDirectText = true;

        [Header("Gesture Recognizers")]
        [Tooltip("GestureRecognizer para mano derecha")]
        [SerializeField] private GestureRecognizer rightHandRecognizer;

        [Tooltip("GestureRecognizer para mano izquierda (opcional)")]
        [SerializeField] private GestureRecognizer leftHandRecognizer;

        [Tooltip("DynamicGestureRecognizer para gestos con movimiento")]
        [SerializeField] private ASL.DynamicGestures.DynamicGestureRecognizer dynamicGestureRecognizer;

        [Header("Sampling Settings")]
        [Tooltip("Intervalo de análisis en segundos (debounce)")]
        [SerializeField] private float analysisInterval = 0.2f;

        [Tooltip("Tiempo que se muestra el feedback de éxito antes de volver a analizar (3s para que el usuario vea el mensaje)")]
        [SerializeField] private float successDisplayDuration = 3f;

        [Header("Current Sign")]
        [Tooltip("Signo actual que se está practicando")]
        [SerializeField] private SignData currentSign;

        [Header("Events")]
        [Tooltip("Se invoca cuando el feedback cambia de estado")]
        public UnityEvent<FeedbackState> onFeedbackStateChanged;

        [Tooltip("Se invoca cuando se detecta éxito en un gesto")]
        public UnityEvent<SignData> onGestureSuccess;

        [Tooltip("Se invoca cuando cambia el mensaje de feedback (útil para integración externa)")]
        public UnityEvent<string> onFeedbackMessageChanged;

        // Estado interno
        private bool isActive = false;
        private float lastAnalysisTime = 0f;
        private float successEndTime = 0f;
        private FeedbackState currentState = FeedbackState.Inactive;
        private StaticGestureResult lastResult;

        // Cache para métricas de gesto dinámico
        private DynamicGestureResult lastDynamicResult;
        private bool directTextValidated = false;

        void Start()
        {
            // Validar componentes
            ValidateComponents();
            EnsureDirectTextMode();

            // Desactivar feedback al inicio
            SetActive(false);
        }

        void OnEnable()
        {
            SubscribeToEvents();
        }

        void OnDisable()
        {
            UnsubscribeFromEvents();
        }

        void Update()
        {
            if (!isActive)
                return;

            // Si estamos mostrando éxito, esperar antes de volver a analizar
            if (currentState == FeedbackState.Success && Time.time < successEndTime)
                return;

            // Debounce: analizar solo cada analysisInterval segundos
            if (Time.time - lastAnalysisTime < analysisInterval)
                return;

            // Ejecutar análisis para gestos estáticos
            if (currentSign != null && !currentSign.requiresMovement)
            {
                AnalyzeCurrentPose();
            }

            lastAnalysisTime = Time.time;
        }

        /// <summary>
        /// Valida que todos los componentes necesarios estén asignados.
        /// </summary>
        private void ValidateComponents()
        {
            if (handPoseAnalyzer == null)
                Debug.LogWarning("[FeedbackSystem] HandPoseAnalyzer no asignado - el análisis de errores por dedo no funcionará");

            if (feedbackUI == null)
                Debug.LogWarning("[FeedbackSystem] FeedbackUI no asignado - no se mostrará feedback textual");

            if (feedbackAudio == null)
                Debug.LogWarning("[FeedbackSystem] FeedbackAudio no asignado - no habrá audio de feedback");

            if (fingerIndicatorVisualizer == null)
                Debug.LogWarning("[FeedbackSystem] FingerIndicatorVisualizer no asignado - no habrá indicadores visuales por dedo");
        }

        /// <summary>
        /// Suscribirse a eventos de los recognizers.
        /// </summary>
        private void SubscribeToEvents()
        {
            // Gestos estáticos
            if (rightHandRecognizer != null)
            {
                rightHandRecognizer.onGestureDetected.AddListener(OnStaticGestureDetected);
                rightHandRecognizer.onGestureEnded.AddListener(OnStaticGestureEnded);
            }

            if (leftHandRecognizer != null)
            {
                leftHandRecognizer.onGestureDetected.AddListener(OnStaticGestureDetected);
                leftHandRecognizer.onGestureEnded.AddListener(OnStaticGestureEnded);
            }

            // Gestos dinámicos
            if (dynamicGestureRecognizer != null)
            {
                dynamicGestureRecognizer.OnGestureStarted += OnDynamicGestureStarted;
                dynamicGestureRecognizer.OnGestureProgress += OnDynamicGestureProgress;
                dynamicGestureRecognizer.OnGestureCompletedStructured += OnDynamicGestureCompletedStructured;
                dynamicGestureRecognizer.OnGestureFailedStructured += OnDynamicGestureFailedStructured;
            }
        }

        /// <summary>
        /// Desuscribirse de eventos.
        /// </summary>
        private void UnsubscribeFromEvents()
        {
            if (rightHandRecognizer != null)
            {
                rightHandRecognizer.onGestureDetected.RemoveListener(OnStaticGestureDetected);
                rightHandRecognizer.onGestureEnded.RemoveListener(OnStaticGestureEnded);
            }

            if (leftHandRecognizer != null)
            {
                leftHandRecognizer.onGestureDetected.RemoveListener(OnStaticGestureDetected);
                leftHandRecognizer.onGestureEnded.RemoveListener(OnStaticGestureEnded);
            }

            if (dynamicGestureRecognizer != null)
            {
                dynamicGestureRecognizer.OnGestureStarted -= OnDynamicGestureStarted;
                dynamicGestureRecognizer.OnGestureProgress -= OnDynamicGestureProgress;
                dynamicGestureRecognizer.OnGestureCompletedStructured -= OnDynamicGestureCompletedStructured;
                dynamicGestureRecognizer.OnGestureFailedStructured -= OnDynamicGestureFailedStructured;
            }
        }

        #region Public API

        /// <summary>
        /// Activa o desactiva el sistema de feedback.
        /// </summary>
        public void SetActive(bool active)
        {
            isActive = active;
            EnsureDirectTextMode();

            if (feedbackUI != null)
                feedbackUI.SetVisible(active);

            if (fingerIndicatorVisualizer != null)
                fingerIndicatorVisualizer.SetVisible(active);

            if (active)
            {
                SetState(FeedbackState.Waiting);
                UpdateFeedbackMessage($"Practice '{currentSign?.signName ?? "sign"}'...");
                if (!useDirectText && feedbackUI != null)
                {
                    feedbackUI.SetWaitingState($"Practice '{currentSign?.signName ?? "sign"}'...");
                }
                feedbackAudio?.PlayStartPractice();
            }
            else
            {
                SetState(FeedbackState.Inactive);
            }

            Debug.Log($"[FeedbackSystem] Sistema de feedback: {(active ? "ACTIVADO" : "DESACTIVADO")}");
        }

        /// <summary>
        /// Establece el signo actual a practicar.
        /// IMPORTANTE: Asegúrate de que el GestureRecognizer también tenga el mismo signo configurado.
        /// </summary>
        public void SetCurrentSign(SignData sign)
        {
            currentSign = sign;

            // Sincronizar con los recognizers si están asignados
            // (Esto es una verificación de seguridad - el LearningController ya debería haberlo hecho)
            if (sign != null && !sign.requiresMovement)
            {
                if (rightHandRecognizer != null && rightHandRecognizer.TargetSign?.signName != sign.signName)
                {
                    rightHandRecognizer.TargetSign = sign;
                    Debug.Log($"[FeedbackSystem] Sincronizado rightHandRecognizer con signo: {sign.signName}");
                }
                if (leftHandRecognizer != null && leftHandRecognizer.TargetSign?.signName != sign.signName)
                {
                    leftHandRecognizer.TargetSign = sign;
                    Debug.Log($"[FeedbackSystem] Sincronizado leftHandRecognizer con signo: {sign.signName}");
                }
            }

            EnsureDirectTextMode();
            UpdateFeedbackMessage($"Make the '{sign?.signName ?? "sign"}' sign...");
            if (!useDirectText && feedbackUI != null)
            {
                feedbackUI.SetWaitingState($"Make the '{sign?.signName ?? "sign"}' sign...");
            }

            // Reset estado al cambiar de signo
            SetState(FeedbackState.Waiting);
            if (fingerIndicatorVisualizer != null)
            {
                fingerIndicatorVisualizer.HideAll();
            }

            Debug.Log($"[FeedbackSystem] Signo configurado: {sign?.signName ?? "ninguno"}");
        }

        /// <summary>
        /// Asigna el TextMeshProUGUI donde se mostrará el feedback directamente.
        /// Útil para usar el feedbackText existente de LearningController.
        /// </summary>
        public void SetDirectFeedbackText(TextMeshProUGUI text)
        {
            directFeedbackText = text;
            useDirectText = text != null;
            directTextValidated = false;
            EnsureDirectTextMode();
        }

        /// <summary>
        /// True si el sistema está activo.
        /// </summary>
        public bool IsActive => isActive;

        /// <summary>
        /// Estado actual del feedback.
        /// </summary>
        public FeedbackState CurrentState => currentState;

        /// <summary>
        /// Último resultado del análisis estático.
        /// </summary>
        public StaticGestureResult LastStaticResult => lastResult;

        /// <summary>
        /// Último resultado del análisis dinámico.
        /// </summary>
        public DynamicGestureResult LastDynamicResult => lastDynamicResult;

        #endregion

        #region Analysis

        /// <summary>
        /// Verifica si el GestureRecognizer está detectando activamente el signo actual.
        /// IMPORTANTE: Solo retorna true si el recognizer está configurado con el MISMO signo que currentSign.
        /// </summary>
        private bool IsGestureCurrentlyDetected()
        {
            if (currentSign == null)
                return false;

            // Verificar con el recognizer de mano derecha
            if (rightHandRecognizer != null && rightHandRecognizer.isActiveAndEnabled)
            {
                // IMPORTANTE: El recognizer DEBE tener el mismo signo que estamos practicando
                if (rightHandRecognizer.TargetSign == null ||
                    rightHandRecognizer.TargetSign.signName != currentSign.signName)
                {
                    Debug.LogWarning($"[FeedbackSystem] Recognizer tiene '{rightHandRecognizer.TargetSign?.signName}' pero debería tener '{currentSign.signName}'");
                    return false;
                }

                if (rightHandRecognizer.IsPerformed)
                {
                    return true;
                }
            }

            // Verificar con el recognizer de mano izquierda
            if (leftHandRecognizer != null && leftHandRecognizer.isActiveAndEnabled)
            {
                // IMPORTANTE: El recognizer DEBE tener el mismo signo que estamos practicando
                if (leftHandRecognizer.TargetSign == null ||
                    leftHandRecognizer.TargetSign.signName != currentSign.signName)
                {
                    return false;
                }

                if (leftHandRecognizer.IsPerformed)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Analiza la pose actual y actualiza el feedback.
        /// </summary>
        private void AnalyzeCurrentPose()
        {
            if (currentSign == null)
            {
                UpdateFeedbackMessage("No sign selected...");
                return;
            }

            // Obtener el estado de detección del GestureRecognizer
            bool isDetectedByRecognizer = IsGestureCurrentlyDetected();

            // Si no hay analyzer, mostrar mensaje basado en el recognizer
            if (handPoseAnalyzer == null)
            {
                if (isDetectedByRecognizer)
                {
                    SetState(FeedbackState.Success);
                    UpdateFeedbackMessage($"Correct! '{currentSign.signName}' detected!");
                    if (fingerIndicatorVisualizer != null)
                        fingerIndicatorVisualizer.ShowHandCorrect(true);
                }
                else
                {
                    SetState(FeedbackState.Waiting);
                    UpdateFeedbackMessage($"Make the '{currentSign.signName}' sign...");
                    if (fingerIndicatorVisualizer != null)
                        fingerIndicatorVisualizer.HideAll();
                }
                return;
            }

            // Analizar pose con errores detallados por dedo, pasando el estado del recognizer
            lastResult = handPoseAnalyzer.Analyze(currentSign, isDetectedByRecognizer, useGlobalMatch: true);

            // Actualizar indicadores visuales basados en el resultado
            if (fingerIndicatorVisualizer != null)
            {
                if (lastResult.isMatchGlobal)
                {
                    // Éxito: mostrar indicador de mano correcta
                    fingerIndicatorVisualizer.HideAllFingerIndicators();
                    fingerIndicatorVisualizer.ShowHandCorrect(true);
                }
                else
                {
                    // No es éxito: mostrar indicadores de error en los dedos
                    fingerIndicatorVisualizer.ShowHandCorrect(false);
                    fingerIndicatorVisualizer.UpdateFromResult(lastResult);
                }
            }

            // Actualizar UI con FeedbackUI si está disponible
            bool shouldUseUI = feedbackUI != null && (!useDirectText || directFeedbackText == null);
            if (shouldUseUI)
                feedbackUI.UpdateFromStaticResult(lastResult);

            // Generar y mostrar mensaje específico
            string message = GenerateDetailedFeedbackMessage(lastResult);
            UpdateFeedbackMessage(message);

            // Actualizar estado basado en el resultado
            if (lastResult.isMatchGlobal)
            {
                SetState(FeedbackState.Success);
                successEndTime = Time.time + successDisplayDuration;
            }
            else if (lastResult.majorErrorCount > 0)
            {
                SetState(FeedbackState.ShowingErrors);
            }
            else if (lastResult.minorErrorCount > 0)
            {
                SetState(FeedbackState.PartialMatch);
            }
            else
            {
                SetState(FeedbackState.Waiting);
            }
        }

        /// <summary>
        /// Genera un mensaje de feedback detallado basado en el resultado del análisis.
        /// </summary>
        private string GenerateDetailedFeedbackMessage(StaticGestureResult result)
        {
            if (result == null)
                return $"Make the '{currentSign?.signName ?? "sign"}' sign...";

            // Solo mostrar éxito cuando el recognizer confirma el match global
            if (result.isMatchGlobal)
            {
                return $"Correct! '{currentSign?.signName}' detected!";
            }

            // Priorizar mensaje resumen generado por el analizador
            if (!string.IsNullOrEmpty(result.summaryMessage))
            {
                return result.summaryMessage;
            }

            // Si no hay errores específicos pero tampoco match global
            if (result.perFingerErrors == null || result.perFingerErrors.Length == 0)
            {
                return $"Adjust your hand for '{currentSign?.signName}'...";
            }

            // Generar mensaje con errores específicos (máximo 2)
            return result.summaryMessage ?? FeedbackMessages.GenerateSummary(result.perFingerErrors, 2);
        }

        /// <summary>
        /// Establece el estado actual del feedback.
        /// </summary>
        private void SetState(FeedbackState newState)
        {
            if (currentState == newState)
                return;

            currentState = newState;
            onFeedbackStateChanged?.Invoke(newState);
        }

        /// <summary>
        /// Actualiza el mensaje de feedback en el texto directo o en FeedbackUI.
        /// </summary>
        private void UpdateFeedbackMessage(string message)
        {
            // Prioridad 1: Texto directo (ej: feedbackText de LearningController)
            if (useDirectText && directFeedbackText != null)
            {
                directFeedbackText.text = message;
            }
            // Prioridad 2: FeedbackUI
            else if (feedbackUI != null)
            {
                // FeedbackUI maneja estados internamente; si estamos en modo panel,
                // solo actualizamos el texto cuando está en estado de espera.
                if (feedbackUI.CurrentState == FeedbackState.Waiting)
                {
                    feedbackUI.SetWaitingState(message);
                }
            }

            // Siempre emitir evento para integración externa
            onFeedbackMessageChanged?.Invoke(message);
        }

        #endregion

        #region Static Gesture Callbacks

        /// <summary>
        /// Callback cuando un gesto estático es detectado por el GestureRecognizer.
        /// Este callback solo maneja el audio y el evento externo.
        /// La actualización visual se hace en AnalyzeCurrentPose() que ya verifica IsGestureCurrentlyDetected().
        /// </summary>
        private void OnStaticGestureDetected(SignData sign)
        {
            if (!isActive || currentSign == null)
                return;

            // IMPORTANTE: Ignorar si estamos en cooldown de éxito
            if (currentState == FeedbackState.Success && Time.time < successEndTime)
            {
                return; // Silenciosamente ignorar - el usuario está viendo el mensaje de éxito
            }

            // IMPORTANTE: Solo procesar si es EXACTAMENTE el signo que estamos practicando
            if (sign == null || sign.signName != currentSign.signName)
            {
                Debug.Log($"[FeedbackSystem] Ignorando detección de '{sign?.signName}' - practicando '{currentSign.signName}'");
                return;
            }

            // Reproducir audio de éxito (solo una vez cuando se confirma)
            feedbackAudio?.PlaySuccess();

            // Emitir evento para que otros sistemas puedan reaccionar (usar currentSign, no sign)
            onGestureSuccess?.Invoke(currentSign);

            // Forzar un análisis inmediato para actualizar el feedback visual
            // Esto evita el delay del analysisInterval
            lastAnalysisTime = 0f; // Reset para permitir análisis inmediato

            Debug.Log($"[FeedbackSystem] Gesto CORRECTO detectado: '{currentSign.signName}'");
        }

        /// <summary>
        /// Callback cuando un gesto estático termina.
        /// </summary>
        private void OnStaticGestureEnded(SignData sign)
        {
            if (!isActive)
                return;

            // Volver a estado waiting después del éxito
            if (currentState == FeedbackState.Success && Time.time > successEndTime)
            {
                SetState(FeedbackState.Waiting);
                UpdateFeedbackMessage($"Make the '{currentSign?.signName ?? "sign"}' sign...");

                if (feedbackUI != null)
                    feedbackUI.SetWaitingState();
            }
        }

        #endregion

        #region Dynamic Gesture Callbacks

        /// <summary>
        /// Callback cuando un gesto dinámico inicia.
        /// </summary>
        private void OnDynamicGestureStarted(string gestureName)
        {
            if (!isActive)
                return;

            // IMPORTANTE: Ignorar si estamos en cooldown de éxito
            if (currentState == FeedbackState.Success && Time.time < successEndTime)
            {
                Debug.Log($"[FeedbackSystem] Ignorando inicio de '{gestureName}' - en cooldown de éxito");
                return;
            }

            SetState(FeedbackState.InProgress);
            UpdateFeedbackMessage($"'{gestureName}' started! Keep moving...");

            if (feedbackUI != null)
                feedbackUI.SetProgressState($"'{gestureName}' started! Keep moving...");

            // Ocultar indicadores de dedos durante el movimiento
            if (fingerIndicatorVisualizer != null)
                fingerIndicatorVisualizer.HideAll();

            Debug.Log($"[FeedbackSystem] Gesto dinámico INICIADO: {gestureName}");
        }

        /// <summary>
        /// Callback de progreso de gesto dinámico.
        /// </summary>
        private void OnDynamicGestureProgress(string gestureName, float progress)
        {
            if (!isActive)
                return;

            // Actualizar progreso (limitar actualizaciones para evitar spam)
            if (progress > 0.1f && (int)(progress * 10) % 2 == 0)
            {
                string progressMsg = $"'{gestureName}'... {Mathf.RoundToInt(progress * 100)}%";
                UpdateFeedbackMessage(progressMsg);

                if (feedbackUI != null)
                    feedbackUI.ShowDynamicProgress(gestureName, progress);
            }
        }

        /// <summary>
        /// Callback cuando un gesto dinámico se completa exitosamente (evento estructurado).
        /// </summary>
        private void OnDynamicGestureCompletedStructured(DynamicGestureResult result)
        {
            if (!isActive || result == null)
                return;

            lastDynamicResult = result;

            SetState(FeedbackState.Success);
            successEndTime = Time.time + successDisplayDuration;

            // Reproducir audio de éxito
            feedbackAudio?.PlaySuccess();

            string message = !string.IsNullOrEmpty(result.troubleshootingMessage)
                ? result.troubleshootingMessage
                : $"Perfect! '{result.gestureName}' completed!";

            UpdateFeedbackMessage(message);

            if (feedbackUI != null)
                feedbackUI.UpdateFromDynamicResult(result);

            // Mostrar indicador de éxito
            if (fingerIndicatorVisualizer != null)
                fingerIndicatorVisualizer.ShowHandCorrect(true);

            Debug.Log($"[FeedbackSystem] Gesto dinámico COMPLETADO: {result.gestureName}");
        }

        /// <summary>
        /// Callback cuando un gesto dinámico falla (evento estructurado).
        /// </summary>
        private void OnDynamicGestureFailedStructured(DynamicGestureResult result)
        {
            if (!isActive || result == null)
                return;

            lastDynamicResult = result;

            SetState(FeedbackState.ShowingErrors);

            // Reproducir audio de error (si está habilitado)
            feedbackAudio?.PlayError();

            string troubleshootingMsg = !string.IsNullOrEmpty(result.troubleshootingMessage)
                ? result.troubleshootingMessage
                : FeedbackMessages.GetTroubleshootingMessage(result.failureReason, result.failedPhase, result.metrics, result.gestureName);

            // Actualizar mensaje con troubleshooting específico
            UpdateFeedbackMessage($"Try again: {troubleshootingMsg}");

            // También actualizar FeedbackUI si existe
            if (feedbackUI != null)
                feedbackUI.UpdateFromDynamicResult(result);

            // Ocultar indicadores durante la corrección del movimiento
            fingerIndicatorVisualizer?.HideAll();

            Debug.Log($"[FeedbackSystem] Gesto dinámico FALLADO: {result.gestureName} - {result.failureReason}");
        }

        /// <summary>
        /// Parsea el string de razón a enum FailureReason.
        /// </summary>
        private FailureReason ParseFailureReason(string reason)
        {
            if (string.IsNullOrEmpty(reason))
                return FailureReason.Unknown;

            string lowerReason = reason.ToLower();

            if (lowerReason.Contains("pose") && lowerReason.Contains("perdida") ||
                lowerReason.Contains("pose") && lowerReason.Contains("lost"))
                return FailureReason.PoseLost;

            if (lowerReason.Contains("velocidad") || lowerReason.Contains("speed"))
            {
                if (lowerReason.Contains("baja") || lowerReason.Contains("low"))
                    return FailureReason.SpeedTooLow;
                if (lowerReason.Contains("alta") || lowerReason.Contains("high"))
                    return FailureReason.SpeedTooHigh;
            }

            if (lowerReason.Contains("distancia") || lowerReason.Contains("distance"))
                return FailureReason.DistanceTooShort;

            if (lowerReason.Contains("direccion") || lowerReason.Contains("direction"))
            {
                if (lowerReason.Contains("cambios") || lowerReason.Contains("changes"))
                    return FailureReason.DirectionChangesInsufficient;
                return FailureReason.DirectionWrong;
            }

            if (lowerReason.Contains("rotacion") || lowerReason.Contains("rotation"))
                return FailureReason.RotationInsufficient;

            if (lowerReason.Contains("circular"))
                return FailureReason.NotCircular;

            if (lowerReason.Contains("timeout") || lowerReason.Contains("tiempo"))
                return FailureReason.Timeout;

            if (lowerReason.Contains("tracking"))
                return FailureReason.TrackingLost;

            if (lowerReason.Contains("final") || lowerReason.Contains("end"))
                return FailureReason.EndPoseMismatch;

            return FailureReason.Unknown;
        }

        /// <summary>
        /// Determina la fase donde ocurrió el fallo.
        /// </summary>
        private GesturePhase DetermineFailedPhase(string reason)
        {
            if (string.IsNullOrEmpty(reason))
                return GesturePhase.Move;

            string lowerReason = reason.ToLower();

            if (lowerReason.Contains("inicial") || lowerReason.Contains("start") ||
                lowerReason.Contains("inicio"))
                return GesturePhase.Start;

            if (lowerReason.Contains("final") || lowerReason.Contains("end") ||
                lowerReason.Contains("completar"))
                return GesturePhase.End;

            return GesturePhase.Move;
        }

        /// <summary>
        /// Garantiza que useDirectText solo esté activo cuando haya un Text asignado; si no, cae al FeedbackPanel de escena.
        /// </summary>
        private void EnsureDirectTextMode()
        {
            if (directTextValidated)
                return;

            if (useDirectText && directFeedbackText == null)
            {
                if (feedbackUI != null)
                {
                    Debug.LogWarning("[FeedbackSystem] useDirectText está activo pero no hay Text asignado. Se usará el FeedbackPanel configurado en escena.");
                    useDirectText = false;
                }
            }

            directTextValidated = true;
        }

        #endregion
    }
}
