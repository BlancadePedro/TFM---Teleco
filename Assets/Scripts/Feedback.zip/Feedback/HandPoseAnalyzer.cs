using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Hands;
using UnityEngine.XR.Management;
using ASL_LearnVR.Data;

namespace ASL_LearnVR.Feedback
{
    /// <summary>
    /// Analiza la pose actual de la mano comparándola con un FingerConstraintProfile.
    /// Genera errores por dedo (perFingerErrors) y un mensaje resumen.
    ///
    /// IMPORTANTE: Este analizador NO reemplaza la detección global (XRHandShape.CheckConditions).
    /// Solo explica POR QUÉ un gesto no coincide, para feedback pedagógico.
    /// </summary>
    public class HandPoseAnalyzer : MonoBehaviour
    {
        [Header("Configuration")]
        [Tooltip("Diccionario de perfiles de constraints por signo")]
        [SerializeField] private List<FingerConstraintProfile> constraintProfiles = new List<FingerConstraintProfile>();

        [Tooltip("Componente XRHandTrackingEvents de la mano a analizar")]
        [SerializeField] private XRHandTrackingEvents handTrackingEvents;

        [Tooltip("Handedness de la mano a analizar")]
        [SerializeField] private Handedness handedness = Handedness.Right;

        [Header("Analysis Settings")]
        [Tooltip("Tolerancia adicional para los rangos de curl (se suma al min y resta al max)")]
        [Range(0f, 0.2f)]
        [SerializeField] private float curlTolerance = 0.1f;

        [Header("Auto-load Profiles")]
        [Tooltip("Cargar automáticamente perfiles de dígitos (0-9) al iniciar")]
        [SerializeField] private bool autoLoadDigitProfiles = true;

        [Tooltip("Cargar automáticamente perfiles de letras del alfabeto (A-Z) al iniciar")]
        [SerializeField] private bool autoLoadAlphabetProfiles = true;

        [Header("Debug")]
        [Tooltip("Mostrar logs de debug")]
        [SerializeField] private bool showDebugLogs = false;

        // Cache para evitar allocations
        private StaticGestureResult cachedResult = new StaticGestureResult();
        private List<FingerError> errorList = new List<FingerError>(5);

        // Cache de datos de mano
        private float[] currentCurlValues = new float[5];
        private bool hasValidHandData = false;

        // Referencia al XRHandSubsystem
        private XRHandSubsystem handSubsystem;

        // Mappings de XRHandJointID a dedos
        private static readonly XRHandJointID[] fingerTipJoints = new XRHandJointID[]
        {
            XRHandJointID.ThumbTip,
            XRHandJointID.IndexTip,
            XRHandJointID.MiddleTip,
            XRHandJointID.RingTip,
            XRHandJointID.LittleTip
        };

        private static readonly XRHandJointID[] fingerProximalJoints = new XRHandJointID[]
        {
            XRHandJointID.ThumbProximal,
            XRHandJointID.IndexProximal,
            XRHandJointID.MiddleProximal,
            XRHandJointID.RingProximal,
            XRHandJointID.LittleProximal
        };

        private static readonly XRHandJointID[] fingerIntermediateJoints = new XRHandJointID[]
        {
            XRHandJointID.ThumbDistal, // Thumb no tiene intermediate, usamos distal
            XRHandJointID.IndexIntermediate,
            XRHandJointID.MiddleIntermediate,
            XRHandJointID.RingIntermediate,
            XRHandJointID.LittleIntermediate
        };

        private static readonly XRHandJointID[] fingerDistalJoints = new XRHandJointID[]
        {
            XRHandJointID.ThumbDistal,
            XRHandJointID.IndexDistal,
            XRHandJointID.MiddleDistal,
            XRHandJointID.RingDistal,
            XRHandJointID.LittleDistal
        };

        void Start()
        {
            if (autoLoadDigitProfiles)
            {
                LoadDigitProfiles();
            }

            if (autoLoadAlphabetProfiles)
            {
                LoadAlphabetProfiles();
            }
        }

        /// <summary>
        /// Carga todos los perfiles de dígitos (0-9) predefinidos.
        /// </summary>
        public void LoadDigitProfiles()
        {
            var digitProfiles = DigitConstraintProfiles.CreateAllDigitProfiles();
            foreach (var profile in digitProfiles)
            {
                RegisterProfile(profile);
            }

            if (showDebugLogs)
            {
                Debug.Log($"[HandPoseAnalyzer] Cargados {digitProfiles.Length} perfiles de dígitos");
            }
        }

        /// <summary>
        /// Carga todos los perfiles de letras del alfabeto (A-Z) predefinidos.
        /// </summary>
        public void LoadAlphabetProfiles()
        {
            var alphabetProfiles = AlphabetConstraintProfiles.CreateAllAlphabetProfiles();
            foreach (var profile in alphabetProfiles)
            {
                RegisterProfile(profile);
            }

            if (showDebugLogs)
            {
                Debug.Log($"[HandPoseAnalyzer] Cargados {alphabetProfiles.Length} perfiles de letras");
            }
        }

        /// <summary>
        /// Registra un perfil de constraints. Se puede llamar desde código o configurar en Inspector.
        /// </summary>
        public void RegisterProfile(FingerConstraintProfile profile)
        {
            if (profile != null && !constraintProfiles.Contains(profile))
            {
                constraintProfiles.Add(profile);
                Debug.Log($"[HandPoseAnalyzer] Perfil registrado: {profile.signName}");
            }
        }

        /// <summary>
        /// Obtiene el perfil de constraints para un signo por nombre.
        /// </summary>
        public FingerConstraintProfile GetProfile(string signName)
        {
            if (string.IsNullOrEmpty(signName))
                return null;

            foreach (var profile in constraintProfiles)
            {
                if (profile != null && profile.signName == signName)
                    return profile;
            }

            return null;
        }

        /// <summary>
        /// Analiza la pose actual de la mano comparándola con el perfil del signo especificado.
        /// </summary>
        /// <param name="signData">El SignData del gesto objetivo</param>
        /// <param name="useGlobalMatch">Si true, usa XRHandShape.CheckConditions para isMatchGlobal</param>
        /// <returns>Resultado del análisis con errores por dedo</returns>
        public StaticGestureResult Analyze(SignData signData, bool useGlobalMatch = true)
        {
            // Llamar a la versión que acepta el estado de detección externo
            // Si no se proporciona, se usará false (no detectado) para evitar falsos positivos
            return Analyze(signData, isDetectedByRecognizer: false, useGlobalMatch);
        }

        /// <summary>
        /// Analiza la pose actual de la mano comparándola con el perfil del signo especificado.
        /// Esta versión acepta el estado de detección del GestureRecognizer para evitar falsos positivos.
        /// </summary>
        /// <param name="signData">El SignData del gesto objetivo</param>
        /// <param name="isDetectedByRecognizer">True si el GestureRecognizer está detectando activamente el signo</param>
        /// <param name="useGlobalMatch">Si true y isDetectedByRecognizer es false, analiza errores de dedos</param>
        /// <returns>Resultado del análisis con errores por dedo</returns>
        public StaticGestureResult Analyze(SignData signData, bool isDetectedByRecognizer, bool useGlobalMatch = true)
        {
            cachedResult = new StaticGestureResult();
            errorList.Clear();

            if (signData == null)
            {
                cachedResult.summaryMessage = "No sign data provided";
                return cachedResult;
            }

            // Obtener perfil de constraints
            FingerConstraintProfile profile = GetProfile(signData.signName);

            // Actualizar datos de curl de la mano
            UpdateHandData();

            if (!hasValidHandData)
            {
                cachedResult.summaryMessage = "Hand not tracked";
                return cachedResult;
            }

            // El match global viene del GestureRecognizer, NO lo calculamos aquí
            // porque no podemos acceder correctamente a XRHandJointsUpdatedEventArgs
            cachedResult.isMatchGlobal = isDetectedByRecognizer;

            // Si el recognizer dice que está detectado, es un éxito
            if (isDetectedByRecognizer)
            {
                cachedResult.summaryMessage = $"Correct! '{signData.signName}' detected!";
                cachedResult.majorErrorCount = 0;
                cachedResult.minorErrorCount = 0;
                cachedResult.perFingerErrors = new FingerError[0];

                if (showDebugLogs)
                {
                    Debug.Log($"[HandPoseAnalyzer] '{signData.signName}' detectado por GestureRecognizer - ÉXITO");
                }
                return cachedResult;
            }

            // Si no hay perfil definido, mostrar mensaje genérico
            if (profile == null)
            {
                if (showDebugLogs)
                    Debug.Log($"[HandPoseAnalyzer] No hay perfil de constraints para '{signData.signName}'");

                cachedResult.summaryMessage = $"Adjust your hand for '{signData.signName}'...";
                return cachedResult;
            }

            // Analizar cada dedo contra el perfil para mostrar errores específicos
            AnalyzeAllFingers(profile);

            // Generar mensaje resumen
            cachedResult.perFingerErrors = errorList.ToArray();
            cachedResult.majorErrorCount = CountErrors(Severity.Major);
            cachedResult.minorErrorCount = CountErrors(Severity.Minor);

            // Generar mensaje basado en errores encontrados
            if (cachedResult.majorErrorCount == 0 && cachedResult.minorErrorCount == 0)
            {
                // Sin errores detectados por el perfil, pero el recognizer no lo detecta
                // Esto puede pasar si el perfil no está bien configurado o la pose no está exacta
                cachedResult.summaryMessage = $"For '{signData.signName}': Hold the pose steady...";
            }
            else
            {
                // Generar mensaje con contexto del signo que se está practicando
                string errorSummary = FeedbackMessages.GenerateSummary(cachedResult.perFingerErrors, 2);
                cachedResult.summaryMessage = $"For '{signData.signName}':\n{errorSummary}";
            }

            if (showDebugLogs)
            {
                Debug.Log($"[HandPoseAnalyzer] Análisis de '{signData.signName}': " +
                         $"Detected={isDetectedByRecognizer}, Major={cachedResult.majorErrorCount}, Minor={cachedResult.minorErrorCount}");
            }

            return cachedResult;
        }

        // NOTA: EvaluateGlobalMatch, CheckShapeConditionsManual y CheckPoseConditionsManual fueron eliminados
        // porque no podemos evaluar XRHandShape.CheckConditions sin XRHandJointsUpdatedEventArgs.
        // La detección global ahora viene directamente del GestureRecognizer a través del parámetro isDetectedByRecognizer.

        /// <summary>
        /// Actualiza los valores de curl actuales de la mano.
        /// </summary>
        private void UpdateHandData()
        {
            hasValidHandData = false;

            var hand = GetCurrentHand();
            if (!hand.isTracked)
                return;

            // Calcular curl para cada dedo
            for (int i = 0; i < 5; i++)
            {
                currentCurlValues[i] = CalculateFingerCurl(hand, (Finger)i);
            }

            hasValidHandData = true;
        }

        /// <summary>
        /// Obtiene la mano actual del subsystem.
        /// </summary>
        private XRHand GetCurrentHand()
        {
            if (handSubsystem == null)
            {
                handSubsystem = XRGeneralSettings.Instance?
                    .Manager?
                    .activeLoader?
                    .GetLoadedSubsystem<XRHandSubsystem>();
            }

            if (handSubsystem == null)
                return default;

            return handedness == Handedness.Right ? handSubsystem.rightHand : handSubsystem.leftHand;
        }

        /// <summary>
        /// Calcula el valor de curl (0-1) para un dedo específico.
        /// 0 = completamente extendido, 1 = completamente cerrado.
        /// </summary>
        private float CalculateFingerCurl(XRHand hand, Finger finger)
        {
            int fingerIndex = (int)finger;

            // Obtener joints del dedo
            var proximalJoint = hand.GetJoint(fingerProximalJoints[fingerIndex]);
            var intermediateJoint = hand.GetJoint(fingerIntermediateJoints[fingerIndex]);
            var distalJoint = hand.GetJoint(fingerDistalJoints[fingerIndex]);
            var tipJoint = hand.GetJoint(fingerTipJoints[fingerIndex]);

            if (!proximalJoint.TryGetPose(out Pose proximalPose) ||
                !intermediateJoint.TryGetPose(out Pose intermediatePose) ||
                !distalJoint.TryGetPose(out Pose distalPose) ||
                !tipJoint.TryGetPose(out Pose tipPose))
            {
                return 0.5f; // Valor neutral si no hay datos
            }

            // Calcular curl basado en ángulos entre segmentos
            float angle1 = CalculateJointAngle(proximalPose, intermediatePose);
            float angle2 = CalculateJointAngle(intermediatePose, distalPose);

            // Para el pulgar, el cálculo es diferente
            if (finger == Finger.Thumb)
            {
                // El pulgar tiene un rango de movimiento diferente
                float thumbCurl = (angle1 + angle2) / 360f; // Normalizar
                return Mathf.Clamp01(thumbCurl * 2f); // Escalar
            }

            // Normalizar ángulos a 0-1
            // Un dedo extendido tiene ángulos cercanos a 180 grados
            // Un dedo cerrado tiene ángulos cercanos a 60-90 grados
            float avgAngle = (angle1 + angle2) / 2f;

            // Mapear: 180 grados -> 0 (extendido), 60 grados -> 1 (cerrado)
            float curl = Mathf.InverseLerp(170f, 60f, avgAngle);

            return Mathf.Clamp01(curl);
        }

        /// <summary>
        /// Calcula el ángulo entre dos poses de joints.
        /// </summary>
        private float CalculateJointAngle(Pose pose1, Pose pose2)
        {
            // Ángulo entre las direcciones forward de cada pose
            Vector3 dir1 = pose1.rotation * Vector3.forward;
            Vector3 dir2 = pose2.rotation * Vector3.forward;

            return Vector3.Angle(dir1, dir2);
        }

        /// <summary>
        /// Analiza todos los dedos contra el perfil de constraints.
        /// IMPORTANTE: Siempre genera feedback para CADA dedo, indicando su estado actual.
        /// </summary>
        private void AnalyzeAllFingers(FingerConstraintProfile profile)
        {
            for (int i = 0; i < 5; i++)
            {
                Finger finger = (Finger)i;
                FingerConstraint constraint = profile.GetConstraint(finger);

                if (constraint == null || !constraint.curl.isEnabled)
                    continue;

                float currentCurl = currentCurlValues[i];

                // Usar tolerancia reducida para feedback más preciso
                float effectiveTolerance = curlTolerance * 0.5f; // Más estricto
                float minWithTolerance = Mathf.Max(0f, constraint.curl.minCurl - effectiveTolerance);
                float maxWithTolerance = Mathf.Min(1f, constraint.curl.maxCurl + effectiveTolerance);

                FingerErrorType errorType = FingerErrorType.None;
                Severity severity = Severity.None;

                // Calcular qué tan lejos está del rango correcto
                float deviation = 0f;
                if (currentCurl < minWithTolerance)
                {
                    errorType = FingerErrorType.TooExtended;
                    deviation = minWithTolerance - currentCurl;
                }
                else if (currentCurl > maxWithTolerance)
                {
                    errorType = FingerErrorType.TooCurled;
                    deviation = currentCurl - maxWithTolerance;
                }

                if (errorType != FingerErrorType.None)
                {
                    // Determinar severidad basada en qué tan lejos está
                    // Mayor = desviación > 0.2, Menor = desviación 0.05-0.2
                    if (deviation > 0.2f)
                        severity = Severity.Major;
                    else if (deviation > 0.05f)
                        severity = Severity.Minor;
                    else
                        severity = Severity.None; // Dentro de tolerancia extendida

                    if (severity != Severity.None)
                    {
                        float expectedValue = (constraint.curl.minCurl + constraint.curl.maxCurl) / 2f;

                        // Generar mensaje específico con valores actuales
                        string fingerName = FeedbackMessages.GetFingerName(finger);
                        string message;
                        if (errorType == FingerErrorType.TooExtended)
                        {
                            message = $"Curl your {fingerName} more ({Mathf.RoundToInt(currentCurl * 100)}% → {Mathf.RoundToInt(constraint.curl.minCurl * 100)}%+)";
                        }
                        else
                        {
                            message = $"Extend your {fingerName} more ({Mathf.RoundToInt(currentCurl * 100)}% → {Mathf.RoundToInt(constraint.curl.maxCurl * 100)}%-)";
                        }

                        // Usar mensaje personalizado si está disponible
                        string customMsg = constraint.GetMessage(errorType);
                        if (!string.IsNullOrEmpty(customMsg) && !customMsg.StartsWith("Adjust"))
                        {
                            message = customMsg;
                        }

                        errorList.Add(new FingerError(
                            finger,
                            errorType,
                            severity,
                            currentCurl,
                            expectedValue,
                            message
                        ));

                        if (showDebugLogs)
                        {
                            Debug.Log($"[HandPoseAnalyzer] {finger}: {errorType} (actual={currentCurl:F2}, rango={minWithTolerance:F2}-{maxWithTolerance:F2}, desv={deviation:F2})");
                        }
                    }
                }
            }

            // Analizar constraints específicos del pulgar
            if (profile.thumb.shouldTouchIndex)
            {
                AnalyzeThumbTouch(profile.thumb, Finger.Index);
            }
            if (profile.thumb.shouldTouchMiddle)
            {
                AnalyzeThumbTouch(profile.thumb, Finger.Middle);
            }
        }

        /// <summary>
        /// Analiza si el pulgar está tocando el dedo especificado.
        /// </summary>
        private void AnalyzeThumbTouch(ThumbConstraint thumbConstraint, Finger targetFinger)
        {
            var hand = GetCurrentHand();
            if (!hand.isTracked)
                return;

            var thumbTip = hand.GetJoint(XRHandJointID.ThumbTip);
            var targetTip = hand.GetJoint(fingerTipJoints[(int)targetFinger]);

            if (!thumbTip.TryGetPose(out Pose thumbPose) ||
                !targetTip.TryGetPose(out Pose targetPose))
                return;

            float distance = Vector3.Distance(thumbPose.position, targetPose.position);

            // Si están a más de 3cm, no están tocándose
            if (distance > 0.03f)
            {
                errorList.Add(FingerError.Create(
                    Finger.Thumb,
                    FingerErrorType.ShouldTouch,
                    Severity.Major,
                    $"Touch your thumb to your {FeedbackMessages.GetFingerName(targetFinger)}"
                ));
            }
        }

        /// <summary>
        /// Cuenta errores de una severidad específica.
        /// </summary>
        private int CountErrors(Severity severity)
        {
            int count = 0;
            foreach (var error in errorList)
            {
                if (error.severity == severity)
                    count++;
            }
            return count;
        }

        /// <summary>
        /// Obtiene los valores de curl actuales (para debug/visualización).
        /// </summary>
        public float[] GetCurrentCurlValues()
        {
            return currentCurlValues;
        }

        /// <summary>
        /// True si hay datos de mano válidos.
        /// </summary>
        public bool HasValidHandData => hasValidHandData;
    }
}
