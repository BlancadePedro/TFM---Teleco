# Sistema de Feedback Pedagógico - Guía de Configuración

## Arquitectura del Sistema

```
┌─────────────────────────────────────────────────────────────────┐
│                      FeedbackSystem.cs                           │
│    (Orquestador principal - debounce 200ms - escucha eventos)   │
└────────────────┬────────────────┬────────────────┬──────────────┘
                 │                │                │
    ┌────────────▼────┐   ┌──────▼──────┐   ┌─────▼─────┐
    │ HandPoseAnalyzer│   │ FeedbackUI  │   │FeedbackAudio│
    │  (errores/dedo) │   │ (panel VR)  │   │ (sonidos)   │
    └────────┬────────┘   └─────────────┘   └─────────────┘
             │
    ┌────────▼────────┐         ┌──────────────────────┐
    │FingerConstraint │         │FingerIndicatorVisual │
    │    Profile      │         │  (halos en joints)   │
    │ (ScriptableObj) │         └──────────────────────┘
    └─────────────────┘
```

## Flujo de Datos

### Gestos Estáticos
1. `LearningController` activa `FeedbackSystem.SetActive(true)`
2. `FeedbackSystem` analiza cada ~200ms usando `HandPoseAnalyzer`
3. `HandPoseAnalyzer` compara pose actual vs `FingerConstraintProfile`
4. Genera `StaticGestureResult` con `perFingerErrors[]` y `summaryMessage`
5. `FeedbackUI` muestra mensaje textual
6. `FingerIndicatorVisualizer` muestra halos en joints con errores
7. `GestureRecognizer.onGestureDetected` → `FeedbackAudio.PlaySuccess()`

### Gestos Dinámicos
1. `DynamicGestureRecognizer.OnGestureStarted` → UI muestra "in progress"
2. `OnGestureProgress` → UI actualiza porcentaje (opcional)
3. `OnGestureCompleted/Failed` → emite `DynamicGestureResult` estructurado
4. `FeedbackSystem` muestra troubleshooting con fase y métricas

---

## Checklist de Configuración en Unity

### 1. Crear Canvas World Space para Feedback

1. **Crear Canvas:**
   - `GameObject > UI > Canvas`
   - Renombrar a `FeedbackCanvas`
   - **Render Mode:** `World Space`
   - **Event Camera:** Arrastrar `Main Camera`
   - **Rect Transform:**
     - Width: 0.3, Height: 0.2 (30cm x 20cm)
     - Posicionar frente al usuario (ej: position 0, 1.2, 0.5)

2. **Añadir Panel de Feedback:**
   - Hijo del Canvas: `UI > Panel`
   - Añadir `TextMeshPro - Text` como hijo
   - Configurar fuente legible en VR (tamaño ~0.02)

3. **Añadir FeedbackUI.cs al Canvas:**
   - Arrastrar componente `FeedbackUI`
   - Asignar referencias:
     - `feedbackText`: el TextMeshPro del panel
     - `feedbackPanel`: el Panel GameObject
     - `statusIcon` (opcional): crear Image hijo

### 2. Crear Prefabs de Indicadores

1. **Indicador de Error (Rojo):**
   - `GameObject > 3D Object > Sphere`
   - Escala: 0.01 (1cm)
   - Material: Rojo semitransparente (Alpha ~0.7)
   - Guardar como Prefab: `Assets/Prefabs/Feedback/ErrorIndicator.prefab`

2. **Indicador de Warning (Naranja):**
   - Igual pero material naranja
   - Guardar: `WarningIndicator.prefab`

3. **Indicador Correcto (Verde):**
   - Igual pero material verde
   - Guardar: `CorrectIndicator.prefab`

4. **Indicador Global de Mano:**
   - Esfera más grande (escala 0.03)
   - Material verde brillante
   - Guardar: `HandCorrectIndicator.prefab`

### 3. Configurar FingerIndicatorVisualizer

1. **Crear GameObject vacío:** `FeedbackVisualizers`
2. **Añadir componente:** `FingerIndicatorVisualizer`
3. **Asignar prefabs:**
   - `errorIndicatorPrefab`: ErrorIndicator
   - `warningIndicatorPrefab`: WarningIndicator
   - `correctIndicatorPrefab`: CorrectIndicator
   - `handCorrectIndicatorPrefab`: HandCorrectIndicator
4. **Configurar:**
   - `handedness`: Right (o Left según mano)
   - `indicatorScale`: 0.025

### 4. Configurar FeedbackAudio

1. **Crear GameObject:** `FeedbackAudio`
2. **Añadir componente:** `FeedbackAudio`
3. **Añadir AudioSource** (se crea automáticamente si no existe)
4. **Asignar clips:**
   - `successClip`: Sonido corto de éxito (ej: "ding")
   - `errorClip`: Sonido de error (opcional, desactivado por defecto)
5. **Configurar:**
   - `volume`: 0.5
   - `playSuccessSound`: true
   - `playErrorSound`: false (recomendado desactivar para no frustrar)

### 5. Configurar HandPoseAnalyzer

1. **Crear GameObject:** `HandPoseAnalyzer`
2. **Añadir componente:** `HandPoseAnalyzer`
3. **Asignar:**
   - `handTrackingEvents`: Arrastrar Right Hand desde XR Origin
   - `handedness`: Right
4. **Crear FingerConstraintProfiles** (ver sección siguiente)

### 6. Crear FingerConstraintProfiles

Para cada signo que quieras feedback detallado:

1. `Assets > Create > ASL Learn VR > Finger Constraint Profile`
2. Configurar:
   - `signName`: Debe coincidir exactamente con SignData.signName
   - Para cada dedo, configurar:
     - `curl.minCurl` / `curl.maxCurl` (0=extendido, 1=cerrado)
     - `curl.severityIfOutOfRange`: Major o Minor
     - Mensajes personalizados (opcional)

**Ejemplos comunes:**

| Signo | Pulgar | Índice | Medio | Anular | Meñique |
|-------|--------|--------|-------|--------|---------|
| A     | 0.2-0.6| 0.7-1.0| 0.7-1.0| 0.7-1.0| 0.7-1.0|
| B     | 0.3-0.8| 0.0-0.25| 0.0-0.25| 0.0-0.25| 0.0-0.25|
| C     | 0.2-0.5| 0.3-0.7| 0.3-0.7| 0.3-0.7| 0.3-0.7|
| 1     | 0.5-1.0| 0.0-0.25| 0.7-1.0| 0.7-1.0| 0.7-1.0|

### 7. Configurar FeedbackSystem

1. **Crear GameObject:** `FeedbackSystem`
2. **Añadir componente:** `FeedbackSystem`
3. **Asignar todas las referencias:**
   - `handPoseAnalyzer`
   - `feedbackUI`
   - `feedbackAudio`
   - `fingerIndicatorVisualizer`
   - `rightHandRecognizer`
   - `leftHandRecognizer` (opcional)
   - `dynamicGestureRecognizer`
4. **Configurar:**
   - `analysisInterval`: 0.2 (200ms debounce)
   - `successDisplayDuration`: 2.0

### 8. Integrar en LearningController

1. En el Inspector de `LearningController`:
   - Asignar `feedbackSystem`: Arrastrar el FeedbackSystem creado

---

## Diccionario de Mensajes

### Errores por Dedo (FingerErrorType)

| Tipo | Mensaje en Inglés |
|------|-------------------|
| TooExtended | "Curl your {finger} more" |
| TooCurled | "Extend your {finger} more" |
| SpreadTooNarrow | "Spread your {finger} apart" |
| SpreadTooWide | "Bring your {finger} closer together" |
| ThumbPositionWrong | "Adjust your thumb position" |
| ShouldTouch | "Touch with your {finger}" |
| ShouldNotTouch | "Separate your {finger}" |
| RotationWrong | "Rotate your hand slightly" |

### Fallos de Gestos Dinámicos (FailureReason)

| Razón | Mensaje | Fase Típica |
|-------|---------|-------------|
| PoseLost | "Keep your hand shape steady {phase}" | Start/During |
| SpeedTooLow | "Move faster! Speed: {speed} m/s" | Move |
| SpeedTooHigh | "Move slower and more controlled" | Move |
| DistanceTooShort | "Make a bigger movement (moved: {dist}m)" | Move |
| DirectionWrong | "Move in the correct direction" | Move |
| DirectionChangesInsufficient | "Make more back-and-forth movements" | Move |
| RotationInsufficient | "Rotate your wrist more ({deg} degrees)" | Move |
| NotCircular | "Make a more circular motion" | Move |
| Timeout | "Complete the gesture faster" | End |
| EndPoseMismatch | "End with the correct hand shape" | End |
| TrackingLost | "Keep your hand visible to the camera" | Any |

---

## Estructura de Archivos Creados

```
Assets/Scripts/Feedback/
├── FeedbackData.cs              # Enums y estructuras
├── FingerConstraintProfile.cs   # ScriptableObject data-driven
├── HandPoseAnalyzer.cs          # Analiza errores por dedo
├── FeedbackUI.cs                # Panel world-space
├── FeedbackAudio.cs             # Sonidos
├── FingerIndicatorVisualizer.cs # Halos en joints
├── FeedbackSystem.cs            # Orquestador principal
└── FEEDBACK_SYSTEM_SETUP.md     # Esta documentación
```

## Modificaciones a Archivos Existentes

- `DynamicGestureRecognizer.cs`: Añadidos eventos estructurados
  - `OnGestureCompletedStructured(DynamicGestureResult)`
  - `OnGestureFailedStructured(DynamicGestureResult)`
  - `GetCurrentMetrics()` → `DynamicMetrics`

- `LearningController.cs`: Añadida referencia a FeedbackSystem
  - Se activa/desactiva automáticamente con el modo Practice

---

## Notas de Diseño

### Por qué NO introspeccionar XRHandShape/XRHandPose

Los componentes de Unity XR Hands (`XRHandShape`, `XRHandPose`) usan `CheckConditions()` que retorna solo `bool`. No exponen qué condición específica falló.

**Solución:** Mantener detección global con `CheckConditions` + crear análisis paralelo con `FingerConstraintProfile` para explicar errores.

### Debounce de 200ms

Evita parpadeos en el feedback visual cuando el tracking fluctúa. El análisis se ejecuta máximo 5 veces por segundo.

### Severidad Major vs Minor

- **Major (rojo):** El dedo está muy lejos del rango → impide reconocimiento
- **Minor (naranja):** Ajuste fino requerido → puede funcionar pero no es óptimo

### Gestos Dinámicos: Sin feedback durante movimiento

Durante el movimiento solo se muestra progreso opcional. El troubleshooting detallado se muestra al completar o fallar, incluyendo:
- Fase de fallo (Start/Move/End)
- Métricas relevantes (velocidad, distancia, rotación)
- Mensaje accionable
