using System;
using UnityEngine;

namespace ASL_LearnVR.Feedback
{
    #region Enums

    /// <summary>
    /// Identificador de cada dedo de la mano.
    /// </summary>
    public enum Finger
    {
        Thumb = 0,
        Index = 1,
        Middle = 2,
        Ring = 3,
        Pinky = 4
    }

    /// <summary>
    /// Severidad del error detectado.
    /// </summary>
    public enum Severity
    {
        /// <summary>Sin error, el dedo está correcto.</summary>
        None = 0,
        /// <summary>Ajuste menor requerido (naranja).</summary>
        Minor = 1,
        /// <summary>Error mayor que impide el reconocimiento (rojo).</summary>
        Major = 2
    }

    /// <summary>
    /// Tipo de error específico por dedo.
    /// </summary>
    public enum FingerErrorType
    {
        None = 0,
        /// <summary>El dedo está demasiado extendido.</summary>
        TooExtended,
        /// <summary>El dedo está demasiado cerrado/curvado.</summary>
        TooCurled,
        /// <summary>Separación insuficiente entre dedos.</summary>
        SpreadTooNarrow,
        /// <summary>Demasiada separación entre dedos.</summary>
        SpreadTooWide,
        /// <summary>El pulgar está en posición incorrecta.</summary>
        ThumbPositionWrong,
        /// <summary>El dedo debería estar tocando otro.</summary>
        ShouldTouch,
        /// <summary>El dedo no debería estar tocando otro.</summary>
        ShouldNotTouch,
        /// <summary>Rotación incorrecta del dedo/mano.</summary>
        RotationWrong
    }

    /// <summary>
    /// Razón de fallo para gestos dinámicos.
    /// </summary>
    public enum FailureReason
    {
        None = 0,
        /// <summary>La pose de la mano se perdió durante el gesto.</summary>
        PoseLost,
        /// <summary>El movimiento fue demasiado lento.</summary>
        SpeedTooLow,
        /// <summary>El movimiento fue demasiado rápido.</summary>
        SpeedTooHigh,
        /// <summary>La distancia recorrida fue insuficiente.</summary>
        DistanceTooShort,
        /// <summary>La dirección del movimiento fue incorrecta.</summary>
        DirectionWrong,
        /// <summary>Cambios de dirección insuficientes (para gestos tipo zigzag).</summary>
        DirectionChangesInsufficient,
        /// <summary>Rotación insuficiente.</summary>
        RotationInsufficient,
        /// <summary>Movimiento no circular (para gestos que lo requieren).</summary>
        NotCircular,
        /// <summary>El gesto tomó demasiado tiempo.</summary>
        Timeout,
        /// <summary>La pose final no coincide.</summary>
        EndPoseMismatch,
        /// <summary>Tracking de la mano perdido.</summary>
        TrackingLost,
        /// <summary>Razón desconocida o no clasificada.</summary>
        Unknown
    }

    /// <summary>
    /// Fase del gesto dinámico donde ocurrió el fallo.
    /// </summary>
    public enum GesturePhase
    {
        /// <summary>No aplica (gesto estático o sin fallo).</summary>
        None = 0,
        /// <summary>Fallo en la pose inicial.</summary>
        Start,
        /// <summary>Fallo durante el movimiento.</summary>
        Move,
        /// <summary>Fallo en la pose final o validación.</summary>
        End
    }

    /// <summary>
    /// Estado general del feedback.
    /// </summary>
    public enum FeedbackState
    {
        /// <summary>Feedback inactivo, sin práctica.</summary>
        Inactive,
        /// <summary>Esperando que el usuario haga el gesto.</summary>
        Waiting,
        /// <summary>Detectando errores, mostrando correcciones.</summary>
        ShowingErrors,
        /// <summary>Gesto parcialmente correcto.</summary>
        PartialMatch,
        /// <summary>Gesto completamente correcto.</summary>
        Success,
        /// <summary>Gesto dinámico en progreso.</summary>
        InProgress
    }

    #endregion

    #region Structures

    /// <summary>
    /// Representa un error específico de un dedo.
    /// </summary>
    [Serializable]
    public struct FingerError
    {
        /// <summary>Dedo afectado.</summary>
        public Finger finger;

        /// <summary>Tipo de error detectado.</summary>
        public FingerErrorType errorType;

        /// <summary>Severidad del error.</summary>
        public Severity severity;

        /// <summary>
        /// Valor actual medido (ej: ángulo de curl 0-1).
        /// </summary>
        public float currentValue;

        /// <summary>
        /// Valor esperado según el constraint.
        /// </summary>
        public float expectedValue;

        /// <summary>
        /// Mensaje de corrección para el usuario.
        /// </summary>
        public string correctionMessage;

        public FingerError(Finger finger, FingerErrorType errorType, Severity severity,
                          float currentValue, float expectedValue, string correctionMessage)
        {
            this.finger = finger;
            this.errorType = errorType;
            this.severity = severity;
            this.currentValue = currentValue;
            this.expectedValue = expectedValue;
            this.correctionMessage = correctionMessage;
        }

        /// <summary>
        /// Crea un error sin valores numéricos específicos.
        /// </summary>
        public static FingerError Create(Finger finger, FingerErrorType errorType,
                                         Severity severity, string message)
        {
            return new FingerError(finger, errorType, severity, 0f, 0f, message);
        }
    }

    /// <summary>
    /// Resultado del análisis de un gesto estático.
    /// </summary>
    [Serializable]
    public class StaticGestureResult
    {
        /// <summary>
        /// True si el gesto cumple las condiciones globales (XRHandShape.CheckConditions).
        /// </summary>
        public bool isMatchGlobal;

        /// <summary>
        /// Errores detectados por cada dedo.
        /// </summary>
        public FingerError[] perFingerErrors;

        /// <summary>
        /// Mensaje resumen priorizado para mostrar al usuario.
        /// </summary>
        public string summaryMessage;

        /// <summary>
        /// Número total de errores mayores.
        /// </summary>
        public int majorErrorCount;

        /// <summary>
        /// Número total de errores menores.
        /// </summary>
        public int minorErrorCount;

        /// <summary>
        /// Timestamp de cuando se generó este resultado.
        /// </summary>
        public float timestamp;

        /// <summary>
        /// True si no hay ningún error.
        /// </summary>
        public bool IsFullyCorrect => majorErrorCount == 0 && minorErrorCount == 0;

        /// <summary>
        /// Obtiene el error más severo para un dedo específico.
        /// </summary>
        public FingerError? GetErrorForFinger(Finger finger)
        {
            if (perFingerErrors == null) return null;

            foreach (var error in perFingerErrors)
            {
                if (error.finger == finger && error.severity != Severity.None)
                    return error;
            }
            return null;
        }

        /// <summary>
        /// Obtiene la severidad para un dedo específico.
        /// </summary>
        public Severity GetSeverityForFinger(Finger finger)
        {
            var error = GetErrorForFinger(finger);
            return error?.severity ?? Severity.None;
        }

        public StaticGestureResult()
        {
            perFingerErrors = new FingerError[5];
            timestamp = 0f; // set when used at runtime, avoid Unity API in constructor
        }
    }

    /// <summary>
    /// Métricas de movimiento para gestos dinámicos.
    /// </summary>
    [Serializable]
    public struct DynamicMetrics
    {
        /// <summary>Velocidad promedio en m/s.</summary>
        public float averageSpeed;

        /// <summary>Velocidad máxima alcanzada en m/s.</summary>
        public float maxSpeed;

        /// <summary>Distancia total recorrida en metros.</summary>
        public float totalDistance;

        /// <summary>Duración del gesto en segundos.</summary>
        public float duration;

        /// <summary>Número de cambios de dirección detectados.</summary>
        public int directionChanges;

        /// <summary>Rotación total en grados.</summary>
        public float totalRotation;

        /// <summary>Score de circularidad (0-1).</summary>
        public float circularityScore;
    }

    /// <summary>
    /// Resultado del análisis de un gesto dinámico.
    /// </summary>
    [Serializable]
    public class DynamicGestureResult
    {
        /// <summary>Nombre del gesto intentado.</summary>
        public string gestureName;

        /// <summary>True si el gesto se completó exitosamente.</summary>
        public bool isSuccess;

        /// <summary>Razón del fallo (si aplica).</summary>
        public FailureReason failureReason;

        /// <summary>Fase donde ocurrió el fallo.</summary>
        public GesturePhase failedPhase;

        /// <summary>Métricas del movimiento.</summary>
        public DynamicMetrics metrics;

        /// <summary>Mensaje de troubleshooting para el usuario.</summary>
        public string troubleshootingMessage;

        /// <summary>Timestamp de cuando se generó este resultado.</summary>
        public float timestamp;

        public DynamicGestureResult()
        {
            timestamp = 0f; // set when used at runtime, avoid Unity API in constructor
        }

        /// <summary>
        /// Crea un resultado de éxito.
        /// </summary>
        public static DynamicGestureResult Success(string gestureName, DynamicMetrics metrics)
        {
            return new DynamicGestureResult
            {
                gestureName = gestureName,
                isSuccess = true,
                failureReason = FailureReason.None,
                failedPhase = GesturePhase.None,
                metrics = metrics,
                troubleshootingMessage = "Gesture completed successfully!",
                timestamp = Time.time
            };
        }

        /// <summary>
        /// Crea un resultado de fallo.
        /// </summary>
        public static DynamicGestureResult Failure(string gestureName, FailureReason reason,
                                                   GesturePhase phase, DynamicMetrics metrics,
                                                   string message)
        {
            return new DynamicGestureResult
            {
                gestureName = gestureName,
                isSuccess = false,
                failureReason = reason,
                failedPhase = phase,
                metrics = metrics,
                troubleshootingMessage = message,
                timestamp = Time.time
            };
        }
    }

    #endregion

    #region Message Dictionary

    /// <summary>
    /// Diccionario de mensajes de corrección por tipo de error.
    /// </summary>
    public static class FeedbackMessages
    {
        /// <summary>
        /// Obtiene el mensaje de corrección para un error de dedo.
        /// </summary>
        public static string GetCorrectionMessage(Finger finger, FingerErrorType errorType)
        {
            string fingerName = GetFingerName(finger);

            return errorType switch
            {
                FingerErrorType.TooExtended => $"Curl your {fingerName} more",
                FingerErrorType.TooCurled => $"Extend your {fingerName} more",
                FingerErrorType.SpreadTooNarrow => $"Spread your {fingerName} apart",
                FingerErrorType.SpreadTooWide => $"Bring your {fingerName} closer together",
                FingerErrorType.ThumbPositionWrong => "Adjust your thumb position",
                FingerErrorType.ShouldTouch => $"Touch with your {fingerName}",
                FingerErrorType.ShouldNotTouch => $"Separate your {fingerName}",
                FingerErrorType.RotationWrong => "Rotate your hand slightly",
                _ => $"Adjust your {fingerName}"
            };
        }

        /// <summary>
        /// Obtiene el mensaje de troubleshooting para un fallo de gesto dinámico.
        /// </summary>
        public static string GetTroubleshootingMessage(FailureReason reason, GesturePhase phase,
                                                       DynamicMetrics metrics, string gestureName)
        {
            string phaseStr = phase switch
            {
                GesturePhase.Start => "at start",
                GesturePhase.Move => "during movement",
                GesturePhase.End => "at end",
                _ => ""
            };

            return reason switch
            {
                FailureReason.PoseLost => $"Keep your hand shape steady {phaseStr}",
                FailureReason.SpeedTooLow => $"Move faster! Speed: {metrics.averageSpeed:F2} m/s",
                FailureReason.SpeedTooHigh => $"Move slower and more controlled",
                FailureReason.DistanceTooShort => $"Make a bigger movement (moved: {metrics.totalDistance:F2}m)",
                FailureReason.DirectionWrong => $"Move in the correct direction for '{gestureName}'",
                FailureReason.DirectionChangesInsufficient => $"Make more back-and-forth movements ({metrics.directionChanges} detected)",
                FailureReason.RotationInsufficient => $"Rotate your wrist more ({metrics.totalRotation:F0} degrees detected)",
                FailureReason.NotCircular => $"Make a more circular motion (score: {metrics.circularityScore:F2})",
                FailureReason.Timeout => "Complete the gesture faster",
                FailureReason.EndPoseMismatch => "End with the correct hand shape",
                FailureReason.TrackingLost => "Keep your hand visible to the camera",
                _ => "Try again with the correct movement"
            };
        }

        /// <summary>
        /// Obtiene el nombre legible del dedo.
        /// </summary>
        public static string GetFingerName(Finger finger)
        {
            return finger switch
            {
                Finger.Thumb => "thumb",
                Finger.Index => "index finger",
                Finger.Middle => "middle finger",
                Finger.Ring => "ring finger",
                Finger.Pinky => "pinky",
                _ => "finger"
            };
        }

        /// <summary>
        /// Genera un mensaje resumen priorizando el error más importante.
        /// </summary>
        public static string GenerateSummary(FingerError[] errors, int maxMessages = 2)
        {
            if (errors == null || errors.Length == 0)
                return "Great! Your hand position is correct.";

            // Ordenar por severidad (Major primero)
            var sortedErrors = new System.Collections.Generic.List<FingerError>();

            // Primero los Major
            foreach (var e in errors)
            {
                if (e.severity == Severity.Major)
                    sortedErrors.Add(e);
            }
            // Luego los Minor
            foreach (var e in errors)
            {
                if (e.severity == Severity.Minor)
                    sortedErrors.Add(e);
            }

            if (sortedErrors.Count == 0)
                return "Great! Your hand position is correct.";

            var messages = new System.Collections.Generic.List<string>();
            int count = Mathf.Min(maxMessages, sortedErrors.Count);

            for (int i = 0; i < count; i++)
            {
                if (!string.IsNullOrEmpty(sortedErrors[i].correctionMessage))
                {
                    messages.Add(sortedErrors[i].correctionMessage);
                }
            }

            return string.Join("\n", messages);
        }
    }

    #endregion
}
